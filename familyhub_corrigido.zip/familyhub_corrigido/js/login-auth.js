// =============================================================================
// FAMILYHUB — login-auth.js
// Autenticação híbrida: tenta backend PHP, cai para localStorage offline.
//
// APRESENTAÇÃO:
// O sistema funciona em DOIS modos:
//   1. Online: autentica via servidor PHP + banco de dados MySQL
//   2. Offline: autentica localmente usando a conta demo no localStorage
//
// Isso permite usar o app tanto com servidor rodando (XAMPP)
// quanto abrindo o index.html direto no navegador sem servidor.
// =============================================================================

const API_BASE = './';

// ─── Limpeza de contas não-demo ───────────────────────────────────────────────
// Ao carregar, garante que só a conta demo existe no localStorage.
// Remove qualquer conta criada anteriormente para manter o ambiente limpo.
(function cleanupNonDemoData() {
  const demoEmail = 'admin@familyhub.com';
  const keysToRemove = [];
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    // Remove DBs de outros usuários que não sejam a conta demo
    if (key && key.startsWith('familyHubDB_') && key !== `familyHubDB_${demoEmail}`) {
      keysToRemove.push(key);
    }
  }
  keysToRemove.forEach(k => localStorage.removeItem(k));

  // Limpa contas não-demo do registro de contas locais
  try {
    const raw = localStorage.getItem('fh_local_accounts');
    if (raw) {
      const accounts = JSON.parse(raw);
      const cleaned  = {};
      if (accounts[demoEmail]) cleaned[demoEmail] = accounts[demoEmail];
      localStorage.setItem('fh_local_accounts', JSON.stringify(cleaned));
    }
  } catch (_) {}
})();

const LOCAL_ACCOUNTS_KEY = 'fh_local_accounts';

// ─── Hash simples djb2 ────────────────────────────────────────────────────────
// Usado APENAS no modo offline/demo — não tem relação com o bcrypt do servidor.
// No modo online, a verificação de senha é feita pelo PHP com bcrypt.
function localHash(str) {
  let h = 5381;
  for (let i = 0; i < str.length; i++) {
    h = ((h << 5) + h) ^ str.charCodeAt(i);
  }
  return (h >>> 0).toString(36);
}

// ─── Gerenciamento de contas locais ──────────────────────────────────────────
function getLocalAccounts() {
  try {
    return JSON.parse(localStorage.getItem(LOCAL_ACCOUNTS_KEY) || '{}');
  } catch {
    return {};
  }
}

function saveLocalAccounts(accounts) {
  localStorage.setItem(LOCAL_ACCOUNTS_KEY, JSON.stringify(accounts));
}

// Garante que a conta demo sempre existe — é a única conta local permitida
function ensureDemoAccount() {
  const demoEmail = 'admin@familyhub.com';
  const demoAccount = {
    id:           'local_admin',
    name:         'Admin Demo',
    email:        demoEmail,
    passwordHash: localHash('123456'), // Senha demo: 123456
    familyName:   'Família Demo',
    phone:        '(11) 99999-9999',
    age:          30,
  };
  saveLocalAccounts({ [demoEmail]: demoAccount });
}

// ─── Login offline ────────────────────────────────────────────────────────────
// Usado como fallback quando o servidor PHP não está disponível.
// Só aceita a conta demo — novas contas exigem servidor.
function loginOffline(email, pass) {
  ensureDemoAccount();
  const accounts = getLocalAccounts();
  const account  = accounts[email.toLowerCase()];

  if (!account)
    return { ok: false, error: 'E-mail não encontrado.' };
  if (account.passwordHash !== localHash(pass))
    return { ok: false, error: 'Senha incorreta.' };

  // Gera um token local simples (não é usado pelo backend)
  const token = 'local_' + Date.now() + '_' + Math.random().toString(36).slice(2);
  const user  = {
    id:         account.id,
    name:       account.name,
    email:      account.email,
    familyName: account.familyName,
  };
  return { ok: true, token, user };
}

// ─── Registro offline ─────────────────────────────────────────────────────────
// Bloqueado no modo offline — novas contas só podem ser criadas com servidor.
function registerOffline(name, email, pass, phone, age) {
  return { ok: false, error: 'Cadastro de novas contas requer conexão com o servidor. Use a conta demo: admin@familyhub.com / 123456' };
}

// ─── Persistência após login bem-sucedido ────────────────────────────────────
// Salva token e dados do usuário no localStorage e redireciona para o dashboard.
function applyLoginSuccess(data) {
  localStorage.setItem('fh_token', data.token);
  localStorage.setItem('fh_user',  JSON.stringify(data.user));

  // Cada usuário tem seu próprio DB isolado no localStorage
  const userEmail = data.user?.email?.toLowerCase() || '';
  const dbKey     = userEmail ? `familyHubDB_${userEmail}` : 'familyHubDB';

  // Se o servidor retornou dados da família, salva localmente
  if (data.family_data) {
    localStorage.setItem(dbKey, JSON.stringify(data.family_data));
  }

  // Migração de dados legados do admin para a nova chave com e-mail
  if (userEmail === 'admin@familyhub.com') {
    const legacy = localStorage.getItem('familyHubDB');
    if (legacy && !localStorage.getItem(dbKey)) {
      localStorage.setItem(dbKey, legacy);
    }
  }

  window.location.href = 'dashboard.html'; // Redireciona após login
}

// ============================================================
//  tryFetch() — Fetch com timeout automático
//
//  APRESENTAÇÃO:
//  Wrapper do fetch nativo do JavaScript que cancela a requisição
//  automaticamente se o servidor demorar mais de 4 segundos.
//
//  Sem esse timeout, se o servidor estiver fora do ar, o usuário
//  ficaria travado esperando para sempre. Com o timeout, após 4s
//  o sistema cai automaticamente para o modo offline.
//
//  AbortController é a API nativa do browser para cancelar fetches.
// ============================================================
async function tryFetch(url, options, timeoutMs = 4000) {
  const controller = new AbortController();
  // Agenda o cancelamento após timeoutMs milissegundos
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { ...options, signal: controller.signal });
    clearTimeout(timer); // Cancela o timeout se a requisição terminar a tempo
    return res;
  } catch (e) {
    clearTimeout(timer);
    throw e; // Relança o erro para o chamador tratar
  }
}

// ============================================================
//  submitLogin() — Login híbrido (online + offline)
//
//  APRESENTAÇÃO:
//  Tenta primeiro o servidor PHP. Se ele responder, autentica
//  com bcrypt e banco de dados real. Se o servidor não responder
//  (timeout ou erro de rede), cai automaticamente para o modo
//  offline usando a conta demo local.
//
//  O usuário não percebe a troca — o comportamento é o mesmo.
// ============================================================
async function submitLogin() {
  hideError('login');

  const email = document.getElementById('login-email').value.trim();
  const pass  = document.getElementById('login-pass').value;

  if (!email || !pass) {
    showError('login', 'Preencha e-mail e senha.');
    return;
  }

  setLoading('login', true);

  // ── 1. Tenta autenticar via servidor PHP ─────────────────
  try {
    const res  = await tryFetch(`${API_BASE}auth.php?action=login`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ email, password: pass }),
    });
    const data = await res.json();

    if (!data.ok && data.offline_fallback) {
      // Servidor respondeu mas banco está indisponível — cai para offline
    } else if (!data.ok) {
      // Servidor respondeu com erro (senha errada, e-mail não encontrado etc.)
      showError('login', data.error || 'Erro ao fazer login.');
      setLoading('login', false, 'Entrar na plataforma');
      return;
    } else {
      // Login bem-sucedido via servidor
      applyLoginSuccess(data);
      return;
    }
  } catch (_) {
    // Servidor indisponível (timeout, sem rede etc.) — cai para offline
  }

  // ── 2. Fallback: autenticação offline com conta demo ─────
  const result = loginOffline(email, pass);
  if (!result.ok) {
    showError('login', result.error);
    setLoading('login', false, 'Entrar na plataforma');
    return;
  }
  applyLoginSuccess(result);
}

// ============================================================
//  submitRegister() — Registro híbrido (online + offline)
//
//  Tenta criar conta via servidor PHP. No modo offline,
//  bloqueia o registro (novas contas exigem banco de dados).
// ============================================================
async function submitRegister() {
  hideError('reg');

  const name  = document.getElementById('reg-name').value.trim();
  const email = document.getElementById('reg-email').value.trim();
  const pass  = document.getElementById('reg-password').value;
  const phone = document.getElementById('reg-phone').value;
  const age   = document.getElementById('reg-age').value;

  if (!name) {
    showError('reg', 'Informe seu nome completo.');
    return;
  }

  setLoading('reg', true);

  // ── 1. Tenta registrar via servidor PHP ──────────────────
  try {
    const res  = await tryFetch(`${API_BASE}auth.php?action=register`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ name, email, password: pass, phone, age: parseInt(age) || null }),
    });
    const data = await res.json();

    if (!data.ok && data.offline_fallback) {
      // Cai para offline
    } else if (!data.ok) {
      showError('reg', data.error || 'Erro ao criar conta.');
      setLoading('reg', false, 'Criar Conta');
      return;
    } else {
      applyLoginSuccess(data);
      return;
    }
  } catch (_) {
    // Servidor indisponível
  }

  // ── 2. Fallback offline (sempre bloqueia registro) ───────
  const result = registerOffline(name, email, pass, phone, parseInt(age) || null);
  if (!result.ok) {
    showError('reg', result.error);
    setLoading('reg', false, 'Criar Conta');
    return;
  }
  applyLoginSuccess(result);
}
