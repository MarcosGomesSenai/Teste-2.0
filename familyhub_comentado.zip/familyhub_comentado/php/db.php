<?php
// ============================================================
//  FamilyHub — Conexão com o Banco de Dados (PDO)
//
//  Este arquivo é o coração da comunicação com o banco MySQL.
//  Ele é importado por todos os outros arquivos PHP do sistema
//  usando require_once, garantindo que as funções estejam
//  disponíveis em qualquer parte do backend.
// ============================================================

// ─── Carrega .env se existir ──────────────────────────────
// Lê o arquivo .env linha por linha e registra cada variável
// no ambiente do servidor, evitando expor credenciais no código.
$envFile = __DIR__ . '/../.env';
if (!file_exists($envFile)) $envFile = __DIR__ . '/.env';
if (file_exists($envFile)) {
    foreach (file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#')) continue;
        [$key, $val] = array_map('trim', explode('=', $line, 2));
        if (!getenv($key)) putenv("$key=$val");
    }
}

// ─── Constantes de configuração ──────────────────────────
// Lê as variáveis do .env. Em produção, nunca deixe os
// valores padrão abaixo — defina sempre via .env.
define('DB_HOST',    getenv('DB_HOST') ?: 'localhost');
define('DB_NAME',    getenv('DB_NAME') ?: 'familyhub');
define('DB_USER',    getenv('DB_USER') ?: 'root');
define('DB_PASS',    getenv('DB_PASS') ?: '');
define('DB_CHARSET', 'utf8mb4'); // Suporte completo a emojis e acentos

// ⚠️  OBRIGATÓRIO definir JWT_SECRET via .env em produção!
define('JWT_SECRET',         getenv('JWT_SECRET') ?: 'TROQUE_ESTA_CHAVE_EM_PRODUCAO');
define('TOKEN_EXPIRE_HOURS', 24 * 7); // Token válido por 7 dias

// ─── Headers CORS ─────────────────────────────────────────
// CORS permite que o JavaScript do frontend se comunique com
// este backend sem ser bloqueado pelo navegador.
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Authorization, Content-Type');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');

// Requisições OPTIONS são o "preflight" do navegador — respondemos
// com 204 (sem conteúdo) para liberar a comunicação.
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// ============================================================
//  getPDO() — Conexão com o banco de dados
//
//  APRESENTAÇÃO:
//  Usa o padrão "Singleton" via variável estática.
//  Não importa quantas vezes getPDO() seja chamada —
//  a conexão com o banco só é aberta UMA vez por requisição.
//  Isso economiza recursos e evita erros de "muitas conexões".
//
//  PDO protege automaticamente contra SQL Injection usando
//  "prepared statements" — nunca concatenamos strings SQL.
// ============================================================
function getPDO(): PDO {
    // Na primeira chamada: $pdo é null, abre a conexão.
    // Nas chamadas seguintes: $pdo já existe, retorna direto.
    static $pdo = null;
    if ($pdo !== null) return $pdo;

    // DSN = Data Source Name — identifica o banco a conectar
    $dsn = sprintf(
        'mysql:host=%s;dbname=%s;charset=%s',
        DB_HOST, DB_NAME, DB_CHARSET
    );

    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,  // Lança exceção em erros
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,        // Retorna array associativo ex: $row['nome']
        PDO::ATTR_EMULATE_PREPARES   => false,                   // Prepared statements reais do MySQL
    ];

    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    return $pdo;
}

// ─── Helpers de resposta JSON ─────────────────────────────
// Padronizam todas as respostas do backend no formato:
// { ok: true/false, ...dados }  — fácil de tratar no JavaScript.

function jsonSuccess(array $data = [], int $status = 200): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => true, ...$data], JSON_UNESCAPED_UNICODE);
    exit;
}

function jsonError(string $message, int $status = 400): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => false, 'error' => $message], JSON_UNESCAPED_UNICODE);
    exit;
}

// ============================================================
//  generateToken() — Gerador de token seguro
//
//  APRESENTAÇÃO:
//  random_bytes(32) usa o gerador criptográfico do sistema
//  operacional — impossível de prever ou adivinhar.
//  bin2hex converte os 32 bytes em 64 caracteres hexadecimais.
//  Esse token é salvo no banco e enviado ao usuário após o login.
//  Toda requisição protegida precisa enviar esse token.
// ============================================================
function generateToken(): string {
    return bin2hex(random_bytes(32)); // 32 bytes = 64 caracteres hex
}

// ─── validateToken() ──────────────────────────────────────
// Verifica se um token existe no banco E ainda não expirou.
// Retorna o ID do usuário dono do token, ou null se inválido.
function validateToken(string $token): ?int {
    try {
        $pdo  = getPDO();
        $stmt = $pdo->prepare(
            // expires_at > NOW() rejeita tokens expirados automaticamente
            'SELECT user_id FROM auth_tokens
             WHERE token = ? AND expires_at > NOW()'
        );
        $stmt->execute([$token]);
        $row = $stmt->fetch();
        return $row ? (int)$row['user_id'] : null;
    } catch (Exception $e) {
        return null;
    }
}

// ============================================================
//  requireAuth() — Proteção de rotas
//
//  APRESENTAÇÃO:
//  Chamada no início de toda rota protegida do sistema.
//  Lê o token do cabeçalho HTTP "Authorization: Bearer <token>",
//  valida no banco e retorna o ID do usuário logado.
//
//  Se o token estiver ausente, inválido ou expirado, encerra
//  a requisição com erro 401 (Não autorizado) — nenhuma linha
//  de código a seguir é executada.
//
//  Isso garante que nenhum dado da família seja acessado
//  por usuários não autenticados.
// ============================================================
function requireAuth(): int {
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';

    // Apache + mod_php às vezes não passa o header Authorization diretamente
    if (!$authHeader && function_exists('apache_request_headers')) {
        $headers     = apache_request_headers();
        $authHeader  = $headers['Authorization'] ?? $headers['authorization'] ?? '';
    }

    // Fallback para nginx / CGI
    if (!$authHeader && isset($_SERVER['HTTP_AUTHORIZATION'])) {
        $authHeader = $_SERVER['HTTP_AUTHORIZATION'];
    }

    // Verifica o formato "Bearer <token>" — se não encontrar, bloqueia com 401
    if (!preg_match('/^Bearer\s+(.+)$/i', $authHeader, $m)) {
        jsonError('Token de autenticação ausente.', 401);
    }

    // Valida o token no banco de dados
    $userId = validateToken($m[1]);
    if (!$userId) {
        // Token inválido ou expirado — usuário precisa fazer login novamente
        jsonError('Token inválido ou expirado. Faça login novamente.', 401);
    }

    return $userId; // Retorna o ID do usuário para uso na rota protegida
}
